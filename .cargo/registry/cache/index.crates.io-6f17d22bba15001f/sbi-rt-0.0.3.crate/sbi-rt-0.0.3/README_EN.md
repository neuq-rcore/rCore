﻿# sbi-rt

- [中文自述文件](README.md)

Runtime library for supervisors to call RISC-V Supervisor Binary Interface (RISC-V SBI).

Chapters implementation in 2.0 specification:

- [x] §3
- [x] §4
- [x] §5
- [x] §6
- [x] §7
- [x] §8
- [x] §9
- [x] §10
- [x] §11
- [x] §13
- [x] §14
- [x] §15
- [x] §16
