﻿# sbi-rt

[![crates.io](https://img.shields.io/crates/v/sbi-rt.svg)](https://crates.io/crates/sbi-rt)
[![Documentation](https://docs.rs/sbi-rt/badge.svg)](https://docs.rs/sbi-rt)
![License](https://img.shields.io/crates/l/sbi-rt.svg)

- [An English README](README_EN.md)

为特权软件提供 RISC-V 特权二进制接口（Supervisor Binary Interface）的运行时库。

2.0 标准各章节的实现情况：

- [x] §3
- [x] §4
- [x] §5
- [x] §6
- [x] §7
- [x] §8
- [x] §9
- [x] §10
- [x] §11
- [x] §12
- [x] §13
- [x] §14
- [x] §15
- [x] §16
